#ifndef SORTPERSON_H
#define SORTPERSON_H
#include "Person.h"

class SortPerson
{   
public:
    static void sort(Person** people,int n);
};

#endif