#include <iostream>
#include <stdlib.h>
extern ;
int main(int argc,char **argv)
{// your code goes here ...
    return 0 ;
}