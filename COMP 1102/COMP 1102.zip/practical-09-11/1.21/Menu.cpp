#include <iostream>
#include <string>

using namespace std;


void Welcome()
{
    cout<<"Good day. Welcome to our resturant!"<<endl;
}

char chooseStatus()
{   
    char user_status;
    cout<<"Are you staff or customer?"<<endl;
    while(true){
        cout<<"Please input s if you are staff,input c if you are customer, input q to Quit."<<endl;
        cin>>user_status;
        if(user_status == 's'||user_status == 'c'||user_status == 'q'){
            return user_status;
        }else{
            cout<<"Please input s if you are staff,input c if you are customer, input q to Quit."<<endl;
            cin>>user_status;
        }
    }
}

char chooseMenu(){
    char menu_status;
    cout<<"What would you like?"<<endl;
    while(true){
        cout<<"Input m for maindish"<<endl;
        cout<<"Input s for snacks"<<endl;
        cout<<"Input d for drinks"<<endl;
        cout<<"Input q for Quit"<<endl;
        cout<<"Input p to Pay your cart"<<endl; 
        cin>>menu_status;
        if(menu_status == 'm'||menu_status == 's'||menu_status == 'd'||menu_status == 'q'||menu_status == 'p'){
            return menu_status;
        }else{
            cout<<"Input m for maindish"<<endl;
            cout<<"Input s for snacks"<<endl;
            cout<<"Input d for drinks"<<endl;
            cout<<"Input q for Quit"<<endl;
            cout<<"Input p to Pay your cart"<<endl; 
            cin>>menu_status;
        }
    }
}

char editWhichMenu(){
    char menu_status;
    cout<<"Which menu you want to edit?"<<endl;
    while(true){
        cout<<"m for maindish"<<endl;
        cout<<"s for snacks"<<endl;
        cout<<"d for drinks"<<endl;
        cout<<"q for Quit"<<endl;
        cin>>menu_status;
        if(menu_status == 'm'||menu_status == 's'||menu_status == 'd'||menu_status == 'q'){
            return menu_status;
        }else{
            cout<<"m for maindish"<<endl;
            cout<<"s for snacks"<<endl;
            cout<<"d for drinks"<<endl;
            cout<<"q for Quit"<<endl;
            cin>>menu_status;
        }
    }
}

int order(){
    int serialNumber;

    cout<<"Please input the number you want to order. Input 0 to exit."<<endl;
    cin>>serialNumber;
    return serialNumber;
}

char chooseAction(){
    char action_status;
    while(true){
        cout<<"View the financial report please input f."<<endl;
        cout<<"Edit menu please input e"<<endl;
        cout<<"Quit input q"<<endl;
        cin>>action_status;
        if(action_status == 'f'||action_status == 'e'||action_status == 'q'){
            return action_status;
        }else{
            cout<<"View the financial report please input f."<<endl;
            cout<<"Edit menu please input a"<<endl;
            cout<<"Quit input q"<<endl;
            cin>>action_status;
        }
    }
}

char AddorDelete(){
    char addordelete;
    while(true){
        cout<<"Add a new dish input a"<<endl;
        cout<<"Delete please input d"<<endl;
        cout<<"Quit input q"<<endl;
        cin>>addordelete;
        if(addordelete == 'a'||addordelete == 'd'||addordelete == 'q'){
            return addordelete;
        }else{
        cout<<"Add a new dish input a"<<endl;
        cout<<"Delete please input d"<<endl;
        cout<<"Quit input q"<<endl;
        cin>>addordelete;
        }
    }
}

int del(){
    int serialNumber;

    cout<<"Please input the number you want to delete. Input 0 to exit."<<endl;
    cin>>serialNumber;
    return serialNumber;
}
