#include <cmath>

extern int binary_to_number(int[], int);

int main(int argc,char **argv)
{
    int array[3] = {1,0,1};
    binary_to_number(array,3);
    return 0 ;
}