#include <iostream>
#include <stdlib.h>

extern double weightedaverage(int array[], int n);

int main(int argc,char **argv)
{
	// your code goes here ...
	return 0 ;
}

