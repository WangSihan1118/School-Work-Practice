#include <iostream>
// function to ...
int median(int array[], int n)
{
	if(n < 1||n % 2 == 0){
		return 0;
	}
	
	int mid = (n / 2) +1;
	
	for(int i = 0;i < n-1;i++){
		
	}
	
	int mid_number = array[mid];
	return mid_number;
}
