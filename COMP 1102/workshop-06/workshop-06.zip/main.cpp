#include <iostream>
#include <string>
#include "Book.h"
#include "Library.h"

using namespace std;

// main program
int main()
{
    Library *aLibrary;
	Book *Book1, *Book2, *Book3;
	Book1 = new Book("booka",1);
	Book2 = new Book("bookb",20);
    Book3 = new Book("bookc",0);
    Book booklist[3] = {*Book1,*Book2,*Book3};
    aLibrary = new Library(booklist);
    aLibrary->borrowBook("bookc");
    aLibrary->returnBook("bookc");
    return 0;
}
